<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
    'page_builder' => array(
        'title'       => esc_html__( 'Blog Posts', 'kerge-shortcodes' ),
        'description' => esc_html__( 'Blog posts grid', 'kerge-shortcodes' ),
        'tab'         => esc_html__( 'Kerge Elements', 'kerge-shortcodes' ),
    )
);
